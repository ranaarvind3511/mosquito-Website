
  # Mosquito Net Business Website

  This is a code bundle for Mosquito Net Business Website. The original project is available at https://www.figma.com/design/gB6eDaaP3PHFclA4Vt0zcI/Mosquito-Net-Business-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  