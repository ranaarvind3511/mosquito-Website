import { Shield, Wind, Leaf, Award, Clock, ThumbsUp } from "lucide-react";
import { Card } from "./ui/card";

export function Features() {
  const features = [
    {
      icon: Shield,
      title: "100% Protection",
      description: "Advanced mesh technology blocks even the smallest mosquitoes while maintaining airflow",
      color: "text-blue-600 bg-blue-50"
    },
    {
      icon: Wind,
      title: "Breathable Design",
      description: "Premium mesh allows fresh air circulation for comfortable sleep throughout the night",
      color: "text-green-600 bg-green-50"
    },
    {
      icon: Leaf,
      title: "Eco-Friendly",
      description: "Chemical-free protection made from sustainable, non-toxic materials safe for babies",
      color: "text-emerald-600 bg-emerald-50"
    },
    {
      icon: Award,
      title: "Premium Quality",
      description: "Durable materials tested to last for years with proper care and maintenance",
      color: "text-purple-600 bg-purple-50"
    },
    {
      icon: Clock,
      title: "Easy Installation",
      description: "Quick 5-minute setup with all necessary hooks and hanging accessories included",
      color: "text-orange-600 bg-orange-50"
    },
    {
      icon: ThumbsUp,
      title: "Satisfaction Guaranteed",
      description: "30-day money-back guarantee if you're not completely satisfied with your purchase",
      color: "text-pink-600 bg-pink-50"
    }
  ];

  return (
    <section id="features" className="py-10 sm:py-12 md:py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 sm:mb-10 md:mb-12">
          <h2 className="text-gray-900 mb-3 sm:mb-4">Why Choose Our Mosquito Nets?</h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-base sm:text-lg">
            Experience the perfect blend of protection, comfort, and quality with our premium mosquito nets
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 md:gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="p-6 hover:shadow-lg transition-shadow duration-300 border-2 hover:border-blue-100">
              <div className={`w-12 h-12 sm:w-14 sm:h-14 rounded-xl ${feature.color} flex items-center justify-center mb-4`}>
                <feature.icon className="w-6 h-6 sm:w-7 sm:h-7" />
              </div>
              <h3 className="text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600 text-sm sm:text-base">{feature.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
