import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Card } from "./ui/card";
import { Phone, Mail, MapPin, MessageCircle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner@2.0.3";

export function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Thank you for your inquiry! We'll contact you shortly.");
    setFormData({ name: "", email: "", phone: "", message: "" });
  };

  const contactInfo = [
    {
      icon: Phone,
      title: "Phone",
      value: "+1 (555) 123-4567",
      link: "tel:+15551234567"
    },
    {
      icon: Mail,
      title: "Email",
      value: "info@netguardpro.com",
      link: "mailto:info@netguardpro.com"
    },
    {
      icon: MapPin,
      title: "Address",
      value: "123 Protection Ave, Safety City, SC 12345",
      link: null
    },
    {
      icon: MessageCircle,
      title: "Live Chat",
      value: "Available 24/7",
      link: null
    }
  ];

  return (
    <section id="contact" className="py-10 sm:py-12 md:py-16 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 sm:mb-10 md:mb-12">
          <h2 className="text-gray-900 mb-3 sm:mb-4">Get In Touch</h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-base sm:text-lg">
            Have questions? We're here to help you find the perfect mosquito net solution
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Contact Form */}
          <Card className="p-6 sm:p-8">
            <h3 className="text-gray-900 mb-6">Send us a message</h3>
            <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
              <div>
                <label className="block text-gray-700 mb-2">Name *</label>
                <Input
                  type="text"
                  required
                  placeholder="Your full name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full"
                />
              </div>
              <div>
                <label className="block text-gray-700 mb-2">Email *</label>
                <Input
                  type="email"
                  required
                  placeholder="your.email@example.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full"
                />
              </div>
              <div>
                <label className="block text-gray-700 mb-2">Phone</label>
                <Input
                  type="tel"
                  placeholder="+1 (555) 000-0000"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full"
                />
              </div>
              <div>
                <label className="block text-gray-700 mb-2">Message *</label>
                <Textarea
                  required
                  placeholder="Tell us about your requirements..."
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full min-h-32"
                />
              </div>
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 py-6">
                Send Message
              </Button>
            </form>
          </Card>

          {/* Contact Information */}
          <div className="space-y-6">
            <div>
              <h3 className="text-gray-900 mb-4">Contact Information</h3>
              <p className="text-gray-600 mb-6 text-sm sm:text-base">
                Reach out to us through any of these channels. Our team is ready to assist you with any questions about our mosquito nets.
              </p>
            </div>
            
            <div className="grid sm:grid-cols-2 lg:grid-cols-1 gap-4">
              {contactInfo.map((info, index) => (
                <Card key={index} className="p-4 sm:p-5 hover:shadow-md transition-shadow">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center flex-shrink-0">
                      <info.icon className="w-5 h-5 sm:w-6 sm:h-6" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-gray-900 mb-1">{info.title}</div>
                      {info.link ? (
                        <a href={info.link} className="text-blue-600 hover:text-blue-700 text-sm sm:text-base break-all">
                          {info.value}
                        </a>
                      ) : (
                        <div className="text-gray-600 text-sm sm:text-base">{info.value}</div>
                      )}
                    </div>
                  </div>
                </Card>
              ))}
            </div>

            {/* Business Hours */}
            <Card className="p-5 sm:p-6 bg-blue-50 border-blue-100">
              <h4 className="text-gray-900 mb-3">Business Hours</h4>
              <div className="space-y-2 text-sm sm:text-base">
                <div className="flex justify-between">
                  <span className="text-gray-600">Monday - Friday:</span>
                  <span className="text-gray-900">9:00 AM - 6:00 PM</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Saturday:</span>
                  <span className="text-gray-900">10:00 AM - 4:00 PM</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Sunday:</span>
                  <span className="text-gray-900">Closed</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
