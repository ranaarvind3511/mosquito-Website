import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Star, ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";

export function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [itemsPerView, setItemsPerView] = useState(3);

  const testimonials = [
    {
      name: "Sarah Johnson",
      location: "California, USA",
      rating: 5,
      text: "Best investment for our family! No more mosquito bites and our kids sleep peacefully through the night. The quality is exceptional.",
      avatar: "SJ"
    },
    {
      name: "Michael Chen",
      location: "Singapore",
      rating: 5,
      text: "Living in a tropical climate, mosquito nets are essential. These are by far the highest quality I've used. Very breathable and durable.",
      avatar: "MC"
    },
    {
      name: "Priya Sharma",
      location: "Mumbai, India",
      rating: 5,
      text: "Easy to install and looks great in our bedroom. The mesh is fine enough to keep out even the tiniest insects. Highly recommended!",
      avatar: "PS"
    },
    {
      name: "David Williams",
      location: "Florida, USA",
      rating: 5,
      text: "Perfect for our beach house! The window screens are amazing and the bed nets are top quality. Installation was super easy.",
      avatar: "DW"
    },
    {
      name: "Emma Thompson",
      location: "London, UK",
      rating: 5,
      text: "Bought these for our summer cottage. Great value for money and excellent customer service. Would definitely buy again!",
      avatar: "ET"
    },
    {
      name: "Carlos Rodriguez",
      location: "Madrid, Spain",
      rating: 5,
      text: "The double bed net is fantastic! Very spacious and the material is high quality. My whole family sleeps better now.",
      avatar: "CR"
    },
    {
      name: "Aisha Patel",
      location: "Dubai, UAE",
      rating: 5,
      text: "Exactly what I needed for my home. The mesh is fine and effective. Plus, it looks elegant in the bedroom!",
      avatar: "AP"
    },
    {
      name: "James Anderson",
      location: "Sydney, Australia",
      rating: 5,
      text: "I travel a lot and the single bed net is my companion everywhere. Compact, lightweight, and very effective. Love it!",
      avatar: "JA"
    },
    {
      name: "Maria Santos",
      location: "Manila, Philippines",
      rating: 5,
      text: "Best mosquito nets in the market! We bought three for our home and they're all working perfectly. Highly recommended!",
      avatar: "MS"
    },
    {
      name: "Robert Taylor",
      location: "Texas, USA",
      rating: 5,
      text: "These nets are a game changer! No more worrying about mosquitoes. The quality exceeded my expectations.",
      avatar: "RT"
    }
  ];

  const handlePrevious = () => {
    setCurrentIndex((prev) => Math.max(0, prev - 1));
  };

  const handleNext = () => {
    const maxIndex = testimonials.length - itemsPerView;
    setCurrentIndex((prev) => Math.min(maxIndex, prev + 1));
  };

  // Responsive items per view
  useState(() => {
    const handleResize = () => {
      if (window.innerWidth < 640) {
        setItemsPerView(1);
      } else if (window.innerWidth < 1024) {
        setItemsPerView(2);
      } else {
        setItemsPerView(3);
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  });

  const visibleTestimonials = testimonials.slice(currentIndex, currentIndex + itemsPerView);
  const canGoBack = currentIndex > 0;
  const canGoNext = currentIndex < testimonials.length - itemsPerView;

  return (
    <section className="py-10 sm:py-12 md:py-16 bg-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 sm:mb-10 md:mb-12">
          <h2 className="text-gray-900 mb-3 sm:mb-4">What Our Customers Say</h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-base sm:text-lg">
            Join thousands of satisfied customers who trust our mosquito nets
          </p>
        </div>

        {/* Testimonials Carousel */}
        <div className="relative">
          {/* Left Arrow */}
          <Button
            onClick={handlePrevious}
            disabled={!canGoBack}
            variant="outline"
            size="icon"
            className={`absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 z-10 bg-white shadow-lg rounded-full w-10 h-10 sm:w-12 sm:h-12 ${
              !canGoBack ? 'opacity-40 cursor-not-allowed' : 'hover:bg-blue-50 hover:border-blue-600'
            }`}
          >
            <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6" />
          </Button>

          {/* Testimonials Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 px-2 sm:px-8">
            {visibleTestimonials.map((testimonial, index) => (
              <Card key={currentIndex + index} className="p-6 bg-white hover:shadow-lg transition-all duration-300">
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 sm:w-5 sm:h-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-700 mb-6 text-sm sm:text-base italic">"{testimonial.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-blue-600 text-white flex items-center justify-center flex-shrink-0">
                    {testimonial.avatar}
                  </div>
                  <div>
                    <div className="text-gray-900">{testimonial.name}</div>
                    <div className="text-gray-500 text-xs sm:text-sm">{testimonial.location}</div>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {/* Right Arrow */}
          <Button
            onClick={handleNext}
            disabled={!canGoNext}
            variant="outline"
            size="icon"
            className={`absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 z-10 bg-white shadow-lg rounded-full w-10 h-10 sm:w-12 sm:h-12 ${
              !canGoNext ? 'opacity-40 cursor-not-allowed' : 'hover:bg-blue-50 hover:border-blue-600'
            }`}
          >
            <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6" />
          </Button>
        </div>

        {/* Progress Indicator */}
        <div className="flex justify-center items-center gap-2 mt-8">
          {Array.from({ length: testimonials.length - itemsPerView + 1 }).map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`h-2 rounded-full transition-all duration-300 ${
                index === currentIndex 
                  ? 'w-8 bg-blue-600' 
                  : 'w-2 bg-gray-300 hover:bg-gray-400'
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
