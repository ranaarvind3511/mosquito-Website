import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Check } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { LeadCaptureDialog } from "./LeadCaptureDialog";

interface Product {
  name: string;
  price: string;
  image: string;
  features: string[];
  popular: boolean;
}

interface ProductsProps {
  onProductClick: (product: Product) => void;
}

export function Products({ onProductClick }: ProductsProps) {
  const [showLeadDialog, setShowLeadDialog] = useState(false);
  const [hasShownDialog, setHasShownDialog] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    // Check if user has already provided details
    const hasProvidedDetails = localStorage.getItem("mosquito_net_leads");
    
    if (hasProvidedDetails && !hasShownDialog) {
      // User has already provided details before, don't show again
      setHasShownDialog(true);
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !hasShownDialog) {
            // User scrolled to products section
            setTimeout(() => {
              setShowLeadDialog(true);
              setHasShownDialog(true);
            }, 1500); // Show popup 1.5 seconds after viewing products
          }
        });
      },
      {
        threshold: 0.3, // Trigger when 30% of the section is visible
      }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, [hasShownDialog]);
  const products = [
    {
      name: "Double Bed Net",
      price: "$49.99",
      image: "https://images.unsplash.com/photo-1761891915873-4d5cfb454dc9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW1pbHklMjBzbGVlcGluZyUyMHBlYWNlZnVsbHl8ZW58MXx8fHwxNzYyMjgwNjUzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      features: ["Size: 200x180x150cm", "Extra fine mesh 196 holes/inch", "Reinforced stitching", "Covers queen & king beds"],
      popular: true
    },
    {
      name: "Single Bed Net",
      price: "$29.99",
      image: "https://images.unsplash.com/photo-1733396006053-2274d3b4764b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3NxdWl0byUyMG5ldCUyMGJlZHxlbnwxfHx8fDE3NjIyODA2NTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      features: ["Size: 190x100x150cm", "Fine mesh 156 holes/inch", "Portable & foldable", "Perfect for solo travelers"],
      popular: false
    },
    {
      name: "Window Screen Net",
      price: "$39.99",
      image: "https://images.unsplash.com/photo-1758998243249-4cc82f0df9e8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aW5kb3clMjBtZXNoJTIwc2NyZWVufGVufDF8fHx8MTc2MjI4MDY1M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      features: ["Customizable size", "Easy magnetic installation", "UV resistant material", "Allows fresh air circulation"],
      popular: false
    }
  ];

  return (
    <>
      <section id="products" ref={sectionRef} className="py-10 sm:py-12 md:py-16 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 sm:mb-10 md:mb-12">
          <h2 className="text-gray-900 mb-3 sm:mb-4">Our Product Range</h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-base sm:text-lg">
            Choose the perfect mosquito net solution for your home and family
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {products.map((product, index) => (
            <Card key={index} className={`overflow-hidden hover:shadow-xl transition-all duration-300 ${product.popular ? 'ring-2 ring-blue-500' : ''}`}>
              {product.popular && (
                <div className="bg-blue-600 text-white text-center py-2">
                  ⭐ Most Popular
                </div>
              )}
              <div className="relative h-48 sm:h-56 overflow-hidden">
                <ImageWithFallback
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover transform hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="p-5 sm:p-6">
                <div className="flex justify-between items-start mb-3 sm:mb-4">
                  <h3 className="text-gray-900">{product.name}</h3>
                  <Badge className="bg-blue-600 text-white">{product.price}</Badge>
                </div>
                <ul className="space-y-2 mb-5 sm:mb-6">
                  {product.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-sm sm:text-base">
                      <Check className="w-4 h-4 sm:w-5 sm:h-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button 
                  onClick={() => onProductClick(product)}
                  className="w-full bg-blue-600 hover:bg-blue-700 py-5 sm:py-6"
                >
                  Get Details
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
    
    <LeadCaptureDialog 
      isOpen={showLeadDialog} 
      onClose={() => setShowLeadDialog(false)} 
    />
    </>
  );
}
