import { Button } from "./ui/button";
import { Shield, Menu, X } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { useState, useEffect } from "react";
import { AnimatedCounter } from "./AnimatedCounter";

export function Hero() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);

  const images = [
    "https://images.unsplash.com/photo-1733396006053-2274d3b4764b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3NxdWl0byUyMG5ldCUyMGJlZHxlbnwxfHx8fDE3NjIyODA2NTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    "https://images.unsplash.com/photo-1664858535422-eb7d9d1603f2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWJ5JTIwbW9zcXVpdG8lMjBuZXR8ZW58MXx8fHwxNzYyMjgyNDg0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    "https://images.unsplash.com/photo-1748215541549-f3b050dc2fed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZWRyb29tJTIwcHJvdGVjdGlvbiUyMG5ldHxlbnwxfHx8fDE3NjIyODI0ODV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % images.length);
    }, 2000);

    return () => clearInterval(timer);
  }, [images.length]);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: 'smooth' });
    setMobileMenuOpen(false);
  };

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center gap-2">
              <Shield className="w-6 h-6 sm:w-8 sm:h-8 text-blue-600" />
              <span className="text-blue-900">NetGuard Pro</span>
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex gap-6">
              <button onClick={() => scrollToSection('home')} className="text-gray-700 hover:text-blue-600 transition-colors">Home</button>
              <button onClick={() => scrollToSection('features')} className="text-gray-700 hover:text-blue-600 transition-colors">Features</button>
              <button onClick={() => scrollToSection('products')} className="text-gray-700 hover:text-blue-600 transition-colors">Products</button>
              <button onClick={() => scrollToSection('contact')} className="text-gray-700 hover:text-blue-600 transition-colors">Contact</button>
            </div>

            {/* Mobile Menu Button */}
            <button 
              className="md:hidden p-2 text-gray-700"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden py-4 border-t">
              <div className="flex flex-col gap-4">
                <button onClick={() => scrollToSection('home')} className="text-gray-700 hover:text-blue-600 transition-colors text-left">Home</button>
                <button onClick={() => scrollToSection('features')} className="text-gray-700 hover:text-blue-600 transition-colors text-left">Features</button>
                <button onClick={() => scrollToSection('products')} className="text-gray-700 hover:text-blue-600 transition-colors text-left">Products</button>
                <button onClick={() => scrollToSection('contact')} className="text-gray-700 hover:text-blue-600 transition-colors text-left">Contact</button>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Content */}
      <div id="home" className="pt-20 md:pt-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 md:py-16">
          <div className="grid md:grid-cols-2 gap-8 md:gap-12 items-center">
            {/* Left Content */}
            <div className="text-center md:text-left order-2 md:order-1">
              <p className="text-gray-600 mb-6 sm:mb-8 text-base sm:text-lg">
                Premium quality mosquito nets designed to keep your family safe from mosquito-borne diseases. Enjoy peaceful nights and healthy living.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                <Button 
                  onClick={() => scrollToSection('products')}
                  className="bg-blue-600 hover:bg-blue-700 px-6 py-6 sm:px-8"
                >
                  Shop Now
                </Button>
                <Button 
                  onClick={() => scrollToSection('contact')}
                  variant="outline" 
                  className="border-blue-600 text-blue-600 hover:bg-blue-50 px-6 py-6 sm:px-8"
                >
                  Get Quote
                </Button>
              </div>
              
              {/* Trust Indicators */}
              <div className="mt-8 sm:mt-12 grid grid-cols-3 gap-4 sm:gap-6">
                <div>
                  <AnimatedCounter end={1000} suffix="+" duration={2500} />
                  <div className="text-gray-600 text-sm">Happy Customers</div>
                </div>
                <div>
                  <AnimatedCounter end={100} suffix="%" duration={2000} />
                  <div className="text-gray-600 text-sm">Safe & Tested</div>
                </div>
                <div>
                  <div className="text-blue-600">24/7</div>
                  <div className="text-gray-600 text-sm">Support</div>
                </div>
              </div>
            </div>

            {/* Right Image Slider */}
            <div className="order-1 md:order-2">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                {images.map((image, index) => (
                  <div
                    key={index}
                    className={`transition-opacity duration-500 ${
                      index === currentSlide ? 'opacity-100' : 'opacity-0 absolute inset-0'
                    }`}
                  >
                    <ImageWithFallback
                      src={image}
                      alt={`Mosquito Net Protection ${index + 1}`}
                      className="w-full h-64 sm:h-80 md:h-96 object-cover"
                    />
                  </div>
                ))}
                <div className="absolute inset-0 bg-gradient-to-t from-blue-900/20 to-transparent"></div>
                
                {/* Slide Indicators */}
                <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2 z-10">
                  {images.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentSlide(index)}
                      className={`w-2 h-2 rounded-full transition-all ${
                        index === currentSlide ? 'bg-white w-6' : 'bg-white/50'
                      }`}
                      aria-label={`Go to slide ${index + 1}`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
