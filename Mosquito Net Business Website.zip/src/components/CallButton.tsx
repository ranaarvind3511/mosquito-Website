import { Phone } from "lucide-react";

export function CallButton() {
  return (
    <a
      href="tel:+15551234567"
      className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-green-600 hover:bg-green-700 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center group"
      aria-label="Call us"
    >
      <Phone className="w-6 h-6 group-hover:scale-110 transition-transform" />
      <span className="absolute right-full mr-3 bg-gray-900 text-white px-3 py-1.5 rounded-lg text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
        Call us now
      </span>
    </a>
  );
}
