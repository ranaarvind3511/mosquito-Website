import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Gift, X } from "lucide-react";
import { toast } from "sonner@2.0.3";

interface LeadCaptureDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export function LeadCaptureDialog({ isOpen, onClose }: LeadCaptureDialogProps) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Prepare the message for WhatsApp
    const message = `🔔 New Lead from Website!\n\n👤 Name: ${name}\n📱 Phone: ${phone}\n📍 Viewed: Products Section\n⏰ Time: ${new Date().toLocaleString()}`;
    
    // Your WhatsApp number (replace with your actual number in international format without + or spaces)
    // Example: For +1 555 123 4567, use: 15551234567
    const whatsappNumber = "15551234567"; // REPLACE THIS WITH YOUR WHATSAPP NUMBER
    
    // Create WhatsApp link
    const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
    
    // Store in localStorage for your records
    const leads = JSON.parse(localStorage.getItem("mosquito_net_leads") || "[]");
    leads.push({
      name,
      phone,
      section: "Products",
      timestamp: new Date().toISOString()
    });
    localStorage.setItem("mosquito_net_leads", JSON.stringify(leads));

    // Log to console (you can see this in browser developer tools)
    console.log("📊 New Lead Captured:", { name, phone, section: "Products", time: new Date() });
    
    // Open WhatsApp in a new tab to send notification
    window.open(whatsappUrl, '_blank');

    setTimeout(() => {
      setIsSubmitting(false);
      toast.success("Thank you! Check your WhatsApp for exclusive offers!");
      onClose();
    }, 1000);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none"
        >
          <X className="h-4 w-4" />
          <span className="sr-only">Close</span>
        </button>
        
        <DialogHeader>
          <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 text-blue-600 mx-auto mb-4">
            <Gift className="w-6 h-6" />
          </div>
          <DialogTitle className="text-center">Get Exclusive Offers!</DialogTitle>
          <DialogDescription className="text-center">
            Share your details to receive special discounts and our premium product catalog on WhatsApp
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div>
            <Label htmlFor="name">Full Name *</Label>
            <Input
              id="name"
              type="text"
              placeholder="Enter your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="phone">Phone Number *</Label>
            <Input
              id="phone"
              type="tel"
              placeholder="+1 (555) 000-0000"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              required
              className="mt-1"
            />
          </div>

          <div className="bg-green-50 border border-green-200 rounded-lg p-3 text-sm">
            <p className="text-green-800">
              ✅ Instant WhatsApp notifications<br />
              ✅ Exclusive discounts up to 25%<br />
              ✅ Free installation guide
            </p>
          </div>

          <div className="flex gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1"
              disabled={isSubmitting}
            >
              Maybe Later
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-blue-600 hover:bg-blue-700"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Sending..." : "Get Offers"}
            </Button>
          </div>

          <p className="text-xs text-gray-500 text-center">
            We respect your privacy. Your information is secure with us.
          </p>
        </form>
      </DialogContent>
    </Dialog>
  );
}
