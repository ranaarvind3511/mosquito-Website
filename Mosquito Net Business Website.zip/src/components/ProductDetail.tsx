import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { ArrowLeft, Check, Shield, Truck, RefreshCw, Phone } from "lucide-react";

interface Product {
  name: string;
  price: string;
  image: string;
  features: string[];
  popular: boolean;
}

interface ProductDetailProps {
  product: Product;
  onBack: () => void;
}

export function ProductDetail({ product, onBack }: ProductDetailProps) {
  const scrollToContact = () => {
    onBack();
    setTimeout(() => {
      const element = document.getElementById('contact');
      element?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  // Additional details based on product type
  const getProductDetails = () => {
    if (product.name === "Double Bed Net") {
      return {
        description: "Our premium Double Bed Net is the perfect solution for couples and families. Designed with extra fine mesh technology, it provides complete protection against mosquitoes while ensuring optimal airflow for a comfortable night's sleep.",
        specifications: [
          "Dimensions: 200cm (L) x 180cm (W) x 150cm (H)",
          "Mesh Type: Extra fine polyester mesh - 196 holes per square inch",
          "Material: 100% high-quality polyester fabric",
          "Weight: 450 grams",
          "Color: White",
          "Installation: Ceiling hanging with reinforced loops",
          "Care: Machine washable at 30°C"
        ],
        benefits: [
          "Provides 100% protection from mosquitoes and insects",
          "Covers queen and king-size beds comfortably",
          "Reinforced stitching for long-lasting durability",
          "Chemical-free and safe for babies and children",
          "Breathable mesh allows fresh air circulation",
          "Easy to install with included hanging kit"
        ],
        package: [
          "1x Double Bed Mosquito Net",
          "4x Ceiling hooks and screws",
          "1x Hanging kit with rope",
          "1x Installation guide",
          "1x Storage bag"
        ]
      };
    } else if (product.name === "Single Bed Net") {
      return {
        description: "Compact and portable, our Single Bed Net is ideal for solo sleepers, travelers, and children's beds. The fine mesh construction ensures complete protection while maintaining a lightweight and easy-to-install design.",
        specifications: [
          "Dimensions: 190cm (L) x 100cm (W) x 150cm (H)",
          "Mesh Type: Fine polyester mesh - 156 holes per square inch",
          "Material: 100% polyester fabric",
          "Weight: 300 grams",
          "Color: White",
          "Installation: Ceiling or frame hanging",
          "Care: Hand wash or machine wash at 30°C"
        ],
        benefits: [
          "Perfect size for single beds and cots",
          "Lightweight and portable for travel",
          "Foldable design for easy storage",
          "Ideal for backpackers and campers",
          "Quick 5-minute installation",
          "Chemical-free protection"
        ],
        package: [
          "1x Single Bed Mosquito Net",
          "2x Ceiling hooks and screws",
          "1x Hanging cord",
          "1x Travel pouch",
          "1x Quick setup guide"
        ]
      };
    } else {
      return {
        description: "Our Window Screen Net is the perfect addition to your home ventilation system. Made with UV-resistant material and featuring a magnetic installation system, it allows fresh air while keeping insects out.",
        specifications: [
          "Size: Customizable (up to 150cm x 180cm)",
          "Mesh Type: Fiberglass mesh - UV resistant",
          "Material: Durable fiberglass with PVC coating",
          "Installation: Magnetic frame system",
          "Color: Gray/Black options available",
          "Durability: Weather-resistant for outdoor use",
          "Care: Wipe clean with damp cloth"
        ],
        benefits: [
          "Customizable to fit any window size",
          "Magnetic installation - no drilling required",
          "UV resistant material for long-lasting use",
          "Allows maximum air circulation",
          "Easy to remove and clean",
          "Suitable for windows and patio doors"
        ],
        package: [
          "1x Window Screen Net (cut to size)",
          "1x Magnetic frame set",
          "1x Measuring tape",
          "1x Installation guide",
          "Adhesive strips for mounting"
        ]
      };
    }
  };

  const details = getProductDetails();

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Header */}
      <div className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Button
            onClick={onBack}
            variant="ghost"
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Products
          </Button>
        </div>
      </div>

      {/* Product Detail */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {/* Product Header */}
        <div className="grid md:grid-cols-2 gap-8 md:gap-12 mb-12">
          {/* Image */}
          <div className="order-2 md:order-1">
            <div className="relative rounded-2xl overflow-hidden shadow-xl">
              {product.popular && (
                <div className="absolute top-4 left-4 z-10">
                  <Badge className="bg-blue-600 text-white px-4 py-2">
                    ⭐ Most Popular
                  </Badge>
                </div>
              )}
              <ImageWithFallback
                src={product.image}
                alt={product.name}
                className="w-full h-64 sm:h-96 object-cover"
              />
            </div>
          </div>

          {/* Product Info */}
          <div className="order-1 md:order-2">
            <h1 className="text-gray-900 mb-4">{product.name}</h1>
            <div className="mb-6">
              <span className="text-blue-600">{product.price}</span>
            </div>
            
            <p className="text-gray-600 mb-6 text-base sm:text-lg leading-relaxed">
              {details.description}
            </p>

            <div className="space-y-4 mb-8">
              <h3 className="text-gray-900">Key Features:</h3>
              <ul className="space-y-3">
                {product.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={scrollToContact}
                className="bg-blue-600 hover:bg-blue-700 px-8 py-6 flex-1"
              >
                Order Now
              </Button>
              <Button 
                onClick={scrollToContact}
                variant="outline" 
                className="border-blue-600 text-blue-600 hover:bg-blue-50 px-8 py-6 flex-1"
              >
                Get Quote
              </Button>
            </div>

            {/* Trust Badges */}
            <div className="grid grid-cols-3 gap-4 mt-8 pt-8 border-t">
              <div className="text-center">
                <Shield className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <div className="text-gray-900 text-sm">Quality Guaranteed</div>
              </div>
              <div className="text-center">
                <Truck className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <div className="text-gray-900 text-sm">Free Shipping</div>
              </div>
              <div className="text-center">
                <RefreshCw className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <div className="text-gray-900 text-sm">30-Day Returns</div>
              </div>
            </div>
          </div>
        </div>

        {/* Detailed Information */}
        <div className="grid md:grid-cols-2 gap-6 sm:gap-8 mb-12">
          {/* Specifications */}
          <Card className="p-6">
            <h3 className="text-gray-900 mb-4">Technical Specifications</h3>
            <ul className="space-y-3">
              {details.specifications.map((spec, idx) => (
                <li key={idx} className="flex items-start gap-3 text-gray-600">
                  <span className="text-blue-600 flex-shrink-0">•</span>
                  <span>{spec}</span>
                </li>
              ))}
            </ul>
          </Card>

          {/* Benefits */}
          <Card className="p-6">
            <h3 className="text-gray-900 mb-4">Product Benefits</h3>
            <ul className="space-y-3">
              {details.benefits.map((benefit, idx) => (
                <li key={idx} className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-600">{benefit}</span>
                </li>
              ))}
            </ul>
          </Card>
        </div>

        {/* Package Contents */}
        <Card className="p-6 sm:p-8 mb-12">
          <h3 className="text-gray-900 mb-4">What's Included in the Package</h3>
          <div className="grid sm:grid-cols-2 gap-4">
            {details.package.map((item, idx) => (
              <div key={idx} className="flex items-center gap-3">
                <div className="w-2 h-2 bg-blue-600 rounded-full flex-shrink-0"></div>
                <span className="text-gray-700">{item}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Call to Action */}
        <Card className="p-8 bg-gradient-to-r from-blue-50 to-green-50 border-blue-200">
          <div className="text-center max-w-2xl mx-auto">
            <h3 className="text-gray-900 mb-3">Ready to Order?</h3>
            <p className="text-gray-600 mb-6">
              Contact us now to place your order or get personalized assistance from our team.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                onClick={scrollToContact}
                className="bg-blue-600 hover:bg-blue-700 px-8 py-6"
              >
                Contact Us Now
              </Button>
              <Button 
                onClick={() => window.location.href = 'tel:+15551234567'}
                variant="outline"
                className="border-blue-600 text-blue-600 hover:bg-white px-8 py-6 flex items-center gap-2 justify-center"
              >
                <Phone className="w-5 h-5" />
                Call +1 (555) 123-4567
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
