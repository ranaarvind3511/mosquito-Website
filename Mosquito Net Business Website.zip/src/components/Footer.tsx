import { Shield, Facebook, Twitter, Instagram, Linkedin } from "lucide-react";

interface Product {
  name: string;
  price: string;
  image: string;
  features: string[];
  popular: boolean;
}

interface FooterProps {
  onProductClick: (product: Product) => void;
}

export function Footer({ onProductClick }: FooterProps) {
  const footerProducts = [
    {
      name: "Single Bed Net",
      price: "$29.99",
      image: "https://images.unsplash.com/photo-1733396006053-2274d3b4764b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3NxdWl0byUyMG5ldCUyMGJlZHxlbnwxfHx8fDE3NjIyODA2NTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      features: ["Size: 190x100x150cm", "Fine mesh 156 holes/inch", "Portable & foldable", "Perfect for solo travelers"],
      popular: false
    },
    {
      name: "Double Bed Net",
      price: "$49.99",
      image: "https://images.unsplash.com/photo-1761891915873-4d5cfb454dc9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW1pbHklMjBzbGVlcGluZyUyMHBlYWNlZnVsbHl8ZW58MXx8fHwxNzYyMjgwNjUzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      features: ["Size: 200x180x150cm", "Extra fine mesh 196 holes/inch", "Reinforced stitching", "Covers queen & king beds"],
      popular: true
    },
    {
      name: "Window Screen Net",
      price: "$39.99",
      image: "https://images.unsplash.com/photo-1758998243249-4cc82f0df9e8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aW5kb3clMjBtZXNoJTIwc2NyZWVufGVufDF8fHx8MTc2MjI4MDY1M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      features: ["Customizable size", "Easy magnetic installation", "UV resistant material", "Allows fresh air circulation"],
      popular: false
    }
  ];

  const handleProductLinkClick = (productName: string) => {
    const product = footerProducts.find(p => p.name === productName);
    if (product) {
      onProductClick(product);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10 md:py-12">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-8 sm:mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Shield className="w-6 h-6 sm:w-8 sm:h-8 text-blue-500" />
              <span className="text-white">NetGuard Pro</span>
            </div>
            <p className="text-gray-400 mb-4 text-sm sm:text-base">
              Premium mosquito nets for healthier, safer living. Protecting families worldwide since 2015.
            </p>
            <div className="flex gap-3">
              <a href="#" className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-gray-800 hover:bg-blue-600 flex items-center justify-center transition-colors">
                <Facebook className="w-4 h-4 sm:w-5 sm:h-5" />
              </a>
              <a href="#" className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-gray-800 hover:bg-blue-600 flex items-center justify-center transition-colors">
                <Twitter className="w-4 h-4 sm:w-5 sm:h-5" />
              </a>
              <a href="#" className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-gray-800 hover:bg-blue-600 flex items-center justify-center transition-colors">
                <Instagram className="w-4 h-4 sm:w-5 sm:h-5" />
              </a>
              <a href="#" className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-gray-800 hover:bg-blue-600 flex items-center justify-center transition-colors">
                <Linkedin className="w-4 h-4 sm:w-5 sm:h-5" />
              </a>
            </div>
          </div>

          {/* Products */}
          <div>
            <h4 className="text-white mb-4">Products</h4>
            <ul className="space-y-2 sm:space-y-3 text-sm sm:text-base">
              <li>
                <button 
                  onClick={() => handleProductLinkClick("Single Bed Net")}
                  className="hover:text-blue-500 transition-colors text-left"
                >
                  Single Bed Nets
                </button>
              </li>
              <li>
                <button 
                  onClick={() => handleProductLinkClick("Double Bed Net")}
                  className="hover:text-blue-500 transition-colors text-left"
                >
                  Double Bed Nets
                </button>
              </li>
              <li>
                <button 
                  onClick={() => handleProductLinkClick("Window Screen Net")}
                  className="hover:text-blue-500 transition-colors text-left"
                >
                  Window Screens
                </button>
              </li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-white mb-4">Company</h4>
            <ul className="space-y-2 sm:space-y-3 text-sm sm:text-base">
              <li><a href="#" className="hover:text-blue-500 transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-blue-500 transition-colors">Our Story</a></li>
              <li><a href="#" className="hover:text-blue-500 transition-colors">Testimonials</a></li>
              <li><a href="#" className="hover:text-blue-500 transition-colors">Blog</a></li>
              <li><a href="#" className="hover:text-blue-500 transition-colors">Careers</a></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="text-white mb-4">Support</h4>
            <ul className="space-y-2 sm:space-y-3 text-sm sm:text-base">
              <li><a href="#" className="hover:text-blue-500 transition-colors">Help Center</a></li>
              <li><a href="#" className="hover:text-blue-500 transition-colors">Installation Guide</a></li>
              <li><a href="#" className="hover:text-blue-500 transition-colors">Shipping Info</a></li>
              <li><a href="#" className="hover:text-blue-500 transition-colors">Returns Policy</a></li>
              <li><a href="#" className="hover:text-blue-500 transition-colors">Contact Us</a></li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-gray-800 flex flex-col sm:flex-row justify-between items-center gap-4 text-sm">
          <p className="text-gray-400 text-center sm:text-left">
            © 2025 NetGuard Pro. All rights reserved.
          </p>
          <div className="flex flex-wrap justify-center gap-4 sm:gap-6">
            <a href="#" className="text-gray-400 hover:text-blue-500 transition-colors">Privacy Policy</a>
            <a href="#" className="text-gray-400 hover:text-blue-500 transition-colors">Terms of Service</a>
            <a href="#" className="text-gray-400 hover:text-blue-500 transition-colors">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
