import { useState } from "react";
import { Hero } from "./components/Hero";
import { Features } from "./components/Features";
import { Products } from "./components/Products";
import { ProductDetail } from "./components/ProductDetail";
import { Testimonials } from "./components/Testimonials";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";
import { CallButton } from "./components/CallButton";
import { Toaster } from "./components/ui/sonner";

interface Product {
  name: string;
  price: string;
  image: string;
  features: string[];
  popular: boolean;
}

export default function App() {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToProducts = () => {
    setSelectedProduct(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Show product detail page if a product is selected
  if (selectedProduct) {
    return (
      <div className="min-h-screen">
        <ProductDetail product={selectedProduct} onBack={handleBackToProducts} />
        <Footer />
        <CallButton />
        <Toaster />
      </div>
    );
  }

  // Show main page
  return (
    <div className="min-h-screen">
      <Hero />
      <Features />
      <Products onProductClick={handleProductClick} />
      <Testimonials />
      <Contact />
      <Footer onProductClick={handleProductClick} />
      <CallButton />
      <Toaster />
    </div>
  );
}
